export class DataNotFoundException extends Error{
    constructor(message){
        super(message);
    }
}