export class EmailNotCollectException extends Error{
    constructor(message){
        super(message);
    }
}