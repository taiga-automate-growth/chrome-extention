export class ApiClientNotFoundException extends Error{
    constructor(message){
        super(message);
    }
}