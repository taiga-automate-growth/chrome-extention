export class RequiredEmptyException extends Error{
    constructor(message){
        super(message);
    }
}