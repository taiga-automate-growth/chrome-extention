chrome.runtime.onMessage.addListener(async function(message, sender, sendResponse) {
    if(message.eventName === 'フォームの取得'){
        const formId = message['GoogleフォームID'];
        console.log(formId);
        const form = await fetch(`https://forms.googleapis.com/v1/forms/${formId}`,{
            method : 'GET'
        });
    
        await console.log(form);
        
        sendResponse(form);
    }
})